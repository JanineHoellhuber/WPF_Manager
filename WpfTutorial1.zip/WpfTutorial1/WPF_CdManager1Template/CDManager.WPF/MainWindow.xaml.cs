﻿using CdManager.Model;
using CDManager.WPF.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CDManager.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Cd> _cds;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Repository repo = Repository.GetInstance();
            _cds = repo.GetAllCds();
            lbxCds.ItemsSource = _cds;

            btnnew.Click += Btnnew_Click;
            btndelete.Click += Btndelete_Click;
            btnEdit.Click += BtnEdit_Click;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Cd selecedCd = lbxCds.SelectedItem as Cd;
            if (selecedCd == null)
            {
                MessageBox.Show("Sie müssen eine Cd ausgewählt haben!");
                return;
            }
            CDWindow cdWindow = new CDWindow(selecedCd);
            cdWindow.ShowDialog();

            Repository repository = Repository.GetInstance();
            _cds = repository.GetAllCds();
            lbxCds.ItemsSource = _cds;
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {

            Cd selecedCd = lbxCds.SelectedItem as Cd;
            if(selecedCd == null)
            {
                MessageBox.Show("Sie müssen eine Cd ausgewählt haben!");
                return;
            }



            Repository repository = Repository.GetInstance();
            repository.DeleteCd(selecedCd);
            _cds = repository.GetAllCds();
            lbxCds.ItemsSource = _cds;

        }

        private void Btnnew_Click(object sender, RoutedEventArgs e)
        {
            CDWindow cdWindow = new CDWindow(null);
            cdWindow.ShowDialog();

            Repository repository = Repository.GetInstance();
            _cds = repository.GetAllCds();
            lbxCds.ItemsSource = _cds;
        }
    }
}
