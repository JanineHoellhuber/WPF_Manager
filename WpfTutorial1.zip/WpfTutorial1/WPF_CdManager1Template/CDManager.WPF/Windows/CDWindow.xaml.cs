﻿using CdManager.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CDManager.WPF.Windows
{
    /// <summary>
    /// Interaction logic for CDWindow.xaml
    /// </summary>
    public partial class CDWindow : Window
    {
        private Cd _cd;
        public CDWindow(Cd cd)
        {
            InitializeComponent();
            Loaded += CDWindow_Loaded;
            _cd = cd;
        }

        private void CDWindow_Loaded(object sender, RoutedEventArgs e)
        {
            btnSave.Click += BtnSave_Click;
            btnCancel.Click += BtnCancel_Click;

            if (_cd == null)
            {
                DataContext = new Cd() { AlbumTitle = "Bitte Titel eigeben", Artist = "Bitte Artist eingeben" };
            }
            else
            {
                DataContext = _cd;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            /*Cd newCd = new Cd();
            newCd.AlbumTitle = tbTitle.Text;
            newCd.Artist = tbArtist.Text;


            Repository.GetInstance().AddCd(newCd);*/

            if(_cd == null)
            {
                Repository.GetInstance().AddCd(DataContext as Cd);
            }
           
            Close();
             
        }
    }
}
